"""
SentimentAI — Model Evaluation & Visualization
Generates performance charts and detailed metrics.
"""

import os
import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import (
    confusion_matrix, classification_report,
    roc_curve, auc, precision_recall_curve
)
from sklearn.preprocessing import label_binarize
from train import load_data, preprocess, build_pipeline

sns.set_theme(style="whitegrid", palette="muted")
COLORS = ["#4C72B0", "#DD8452", "#55A868"]
LABELS = ["negative", "neutral", "positive"]
OUT_DIR = "outputs"
os.makedirs(OUT_DIR, exist_ok=True)


def plot_confusion_matrix(y_true, y_pred):
    cm = confusion_matrix(y_true, y_pred, labels=LABELS)
    fig, ax = plt.subplots(figsize=(6, 5))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                xticklabels=LABELS, yticklabels=LABELS, ax=ax)
    ax.set_xlabel("Predicted")
    ax.set_ylabel("Actual")
    ax.set_title("Confusion Matrix")
    fig.tight_layout()
    path = f"{OUT_DIR}/confusion_matrix.png"
    fig.savefig(path, dpi=150)
    print(f"[SAVED] {path}")
    plt.close(fig)


def plot_class_distribution(y):
    counts = pd.Series(y).value_counts().reindex(LABELS, fill_value=0)
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.bar(counts.index, counts.values, color=COLORS)
    ax.set_title("Class Distribution")
    ax.set_xlabel("Sentiment")
    ax.set_ylabel("Count")
    for i, v in enumerate(counts.values):
        ax.text(i, v + 0.1, str(v), ha="center", fontweight="bold")
    fig.tight_layout()
    path = f"{OUT_DIR}/class_distribution.png"
    fig.savefig(path, dpi=150)
    print(f"[SAVED] {path}")
    plt.close(fig)


def plot_feature_importance(pipeline, top_n=20):
    """Show top TF-IDF features by coefficient magnitude (logistic only)."""
    clf = pipeline.named_steps["clf"]
    if not hasattr(clf, "coef_"):
        print("[SKIP] Feature importance only supported for linear models.")
        return
    tfidf = pipeline.named_steps["tfidf"]
    features = np.array(tfidf.get_feature_names_out())
    for i, cls in enumerate(pipeline.classes_):
        coefs = clf.coef_[i] if clf.coef_.ndim > 1 else clf.coef_[0]
        top_idx = np.argsort(np.abs(coefs))[-top_n:]
        top_feats = features[top_idx]
        top_coefs = coefs[top_idx]
        fig, ax = plt.subplots(figsize=(7, 5))
        colors = ["#DD8452" if c < 0 else "#4C72B0" for c in top_coefs]
        ax.barh(top_feats, top_coefs, color=colors)
        ax.set_title(f"Top Features — Class: {cls}")
        ax.set_xlabel("Coefficient")
        fig.tight_layout()
        path = f"{OUT_DIR}/features_{cls}.png"
        fig.savefig(path, dpi=150)
        print(f"[SAVED] {path}")
        plt.close(fig)


def main():
    from sklearn.model_selection import train_test_split

    df = load_data()
    df = preprocess(df)
    X, y = df["text"].values, df["label"].values

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    pipeline = build_pipeline("logistic")
    pipeline.fit(X_train, y_train)
    y_pred = pipeline.predict(X_test)

    print("\n=== Classification Report ===")
    print(classification_report(y_test, y_pred))

    plot_class_distribution(y)
    plot_confusion_matrix(y_test, y_pred)
    plot_feature_importance(pipeline)
    print("\n[DONE] All evaluation outputs saved to ./outputs/")


if __name__ == "__main__":
    main()
