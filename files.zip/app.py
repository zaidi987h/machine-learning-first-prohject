"""
SentimentAI — REST API
Serves the trained sentiment model via Flask.

Endpoints:
  POST /predict        — Single text prediction
  POST /predict/batch  — Batch predictions
  GET  /health         — Health check
"""

import os
import joblib
import numpy as np
from flask import Flask, request, jsonify
from datetime import datetime

app = Flask(__name__)

# ── Load Model ───────────────────────────────────────────────────────────────
MODEL_PATH = os.getenv("MODEL_PATH", "models/sentiment_model.pkl")
pipeline = None

def load_model():
    global pipeline
    if os.path.exists(MODEL_PATH):
        pipeline = joblib.load(MODEL_PATH)
        print(f"[INFO] Model loaded from {MODEL_PATH}")
    else:
        print(f"[WARN] Model not found at {MODEL_PATH}. Run train.py first.")


# ── Routes ───────────────────────────────────────────────────────────────────
@app.route("/health", methods=["GET"])
def health():
    return jsonify({
        "status": "ok",
        "model_loaded": pipeline is not None,
        "timestamp": datetime.utcnow().isoformat() + "Z"
    })


@app.route("/predict", methods=["POST"])
def predict():
    if pipeline is None:
        return jsonify({"error": "Model not loaded"}), 503

    data = request.get_json(force=True)
    text = data.get("text", "").strip()
    if not text:
        return jsonify({"error": "'text' field is required"}), 400

    label = pipeline.predict([text])[0]
    proba = pipeline.predict_proba([text])[0]
    confidence = {cls: round(float(p), 4)
                  for cls, p in zip(pipeline.classes_, proba)}

    return jsonify({
        "text": text,
        "sentiment": label,
        "confidence": confidence,
        "timestamp": datetime.utcnow().isoformat() + "Z"
    })


@app.route("/predict/batch", methods=["POST"])
def predict_batch():
    if pipeline is None:
        return jsonify({"error": "Model not loaded"}), 503

    data = request.get_json(force=True)
    texts = data.get("texts", [])
    if not texts or not isinstance(texts, list):
        return jsonify({"error": "'texts' must be a non-empty list"}), 400

    labels = pipeline.predict(texts)
    probas = pipeline.predict_proba(texts)

    results = []
    for text, label, proba in zip(texts, labels, probas):
        confidence = {cls: round(float(p), 4)
                      for cls, p in zip(pipeline.classes_, proba)}
        results.append({
            "text": text,
            "sentiment": label,
            "confidence": confidence
        })

    return jsonify({"results": results, "count": len(results)})


# ── Main ─────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    load_model()
    app.run(host="0.0.0.0", port=5000, debug=False)
