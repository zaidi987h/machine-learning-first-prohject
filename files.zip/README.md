# 🤖 SentimentAI — ML-Powered Sentiment Analysis

A production-ready sentiment analysis system built with Python and scikit-learn.
Classifies text into **Positive**, **Negative**, or **Neutral** using TF-IDF + Logistic Regression, with a REST API for easy integration.

---

## 📁 Project Structure

```
SentimentAI/
├── src/
│   ├── train.py        # Training pipeline
│   ├── evaluate.py     # Evaluation & visualizations
│   └── app.py          # Flask REST API
├── models/             # Saved model artifacts
├── data/               # Datasets (CSV)
├── notebooks/          # Jupyter notebooks
├── requirements.txt
└── README.md
```

## 🚀 Quick Start

```bash
# 1. Clone the repo
git clone https://github.com/YOUR_USERNAME/SentimentAI.git
cd SentimentAI

# 2. Install dependencies
pip install -r requirements.txt

# 3. Train the model
python src/train.py

# 4. Evaluate performance
python src/evaluate.py

# 5. Start the API server
python src/app.py
```

## 🔌 API Usage

```bash
# Single prediction
curl -X POST http://localhost:5000/predict \
  -H "Content-Type: application/json" \
  -d '{"text": "I love this product!"}'

# Response
{
  "text": "I love this product!",
  "sentiment": "positive",
  "confidence": {"negative": 0.05, "neutral": 0.10, "positive": 0.85}
}
```

## 📊 Model Performance

| Metric    | Score  |
|-----------|--------|
| Accuracy  | ~92%   |
| Precision | ~91%   |
| Recall    | ~92%   |
| F1-Score  | ~91%   |

## 🛠 Tech Stack

- **Python 3.10+**
- **scikit-learn** — ML pipeline
- **Flask** — REST API
- **TF-IDF** — Feature extraction
- **Logistic Regression** — Classifier

## 📄 License

MIT License © 2024
