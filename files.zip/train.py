"""
SentimentAI - Sentiment Analysis using Machine Learning
Train and evaluate sentiment classification models.
"""

import os
import numpy as np
import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import (
    accuracy_score, classification_report,
    confusion_matrix, roc_auc_score
)
from sklearn.pipeline import Pipeline
import warnings
warnings.filterwarnings("ignore")


# ── Sample Dataset ──────────────────────────────────────────────────────────
SAMPLE_DATA = [
    ("I absolutely love this product! It's amazing.", "positive"),
    ("This is the worst purchase I've ever made.", "negative"),
    ("Pretty decent, does what it promises.", "neutral"),
    ("Fantastic quality and fast shipping!", "positive"),
    ("Broke after two days. Terrible build quality.", "negative"),
    ("Average product, nothing special.", "neutral"),
    ("Exceeded my expectations in every way!", "positive"),
    ("Complete waste of money, very disappointed.", "negative"),
    ("Works okay, but could be better.", "neutral"),
    ("Best product I've bought this year!", "positive"),
    ("Poor customer service and faulty product.", "negative"),
    ("Decent value for the price.", "neutral"),
    ("Outstanding performance and great design.", "positive"),
    ("Stopped working after a week.", "negative"),
    ("It's fine for casual use.", "neutral"),
    ("Highly recommend to everyone!", "positive"),
    ("Never buying from this brand again.", "negative"),
    ("Does the job, nothing more.", "neutral"),
    ("Incredible product, five stars!", "positive"),
    ("Arrived damaged and no response from seller.", "negative"),
]


def load_data(filepath: str = None) -> pd.DataFrame:
    """Load dataset from file or use built-in sample data."""
    if filepath and os.path.exists(filepath):
        df = pd.read_csv(filepath)
        print(f"[INFO] Loaded {len(df)} records from {filepath}")
    else:
        df = pd.DataFrame(SAMPLE_DATA, columns=["text", "label"])
        print(f"[INFO] Using sample dataset ({len(df)} records)")
    return df


def preprocess(df: pd.DataFrame) -> pd.DataFrame:
    """Clean and preprocess text data."""
    df = df.dropna(subset=["text", "label"])
    df["text"] = df["text"].str.strip().str.lower()
    df["text_length"] = df["text"].apply(len)
    df["word_count"] = df["text"].apply(lambda x: len(x.split()))
    return df


def build_pipeline(model_name: str = "logistic") -> Pipeline:
    """Build a sklearn Pipeline with TF-IDF + classifier."""
    models = {
        "logistic":   LogisticRegression(max_iter=1000, C=1.0, random_state=42),
        "naive_bayes": MultinomialNB(alpha=0.1),
        "random_forest": RandomForestClassifier(n_estimators=100, random_state=42),
        "gradient_boosting": GradientBoostingClassifier(n_estimators=50, random_state=42),
    }
    if model_name not in models:
        raise ValueError(f"Unknown model '{model_name}'. Choose from: {list(models)}")

    return Pipeline([
        ("tfidf", TfidfVectorizer(
            ngram_range=(1, 2),
            max_features=10_000,
            sublinear_tf=True,
            stop_words="english"
        )),
        ("clf", models[model_name]),
    ])


def evaluate(pipeline, X_test, y_test) -> dict:
    """Evaluate the trained model and return metrics."""
    y_pred = pipeline.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    report = classification_report(y_test, y_pred, output_dict=True)
    cm = confusion_matrix(y_test, y_pred)
    print(f"\n{'='*50}")
    print(f"  Accuracy : {acc:.4f}")
    print(f"{'='*50}")
    print(classification_report(y_test, y_pred))
    print("Confusion Matrix:")
    print(cm)
    return {"accuracy": acc, "report": report, "confusion_matrix": cm}


def save_model(pipeline, path: str = "models/sentiment_model.pkl"):
    """Persist the trained pipeline to disk."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    joblib.dump(pipeline, path)
    print(f"\n[INFO] Model saved → {path}")


def main():
    print("=" * 50)
    print("  SentimentAI — Training Pipeline")
    print("=" * 50)

    # 1. Load & preprocess
    df = load_data()
    df = preprocess(df)

    X, y = df["text"].values, df["label"].values
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    print(f"[INFO] Train: {len(X_train)} | Test: {len(X_test)}")

    # 2. Train
    model_name = "logistic"
    print(f"[INFO] Training model: {model_name}")
    pipeline = build_pipeline(model_name)
    pipeline.fit(X_train, y_train)

    # 3. Evaluate
    metrics = evaluate(pipeline, X_test, y_test)

    # 4. Save
    save_model(pipeline)

    # 5. Quick inference demo
    print("\n[DEMO] Inference on new sentences:")
    samples = [
        "I love this so much!",
        "This is absolutely terrible.",
        "It's okay, nothing special.",
    ]
    for s in samples:
        pred = pipeline.predict([s])[0]
        proba = pipeline.predict_proba([s])[0]
        labels = pipeline.classes_
        print(f"  '{s}' → {pred.upper()} "
              f"({', '.join(f'{l}={p:.2f}' for l, p in zip(labels, proba))})")


if __name__ == "__main__":
    main()
